import React from 'react';

class SomeContent extends React.Component {
    render() {
        return (
            <div className="some-content">
                SOME OTHER CONTENT HERE
            </div>
        )
    }
}

export default SomeContent;
