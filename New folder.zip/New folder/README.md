# sabre-assessment
Test Assessment

To see the result run 
    *npm install*
    *npm run webpack*
    open index.html in browser directly...